#!/bin/bash

tail -f -n600 ./logs/gisgraphy.log




