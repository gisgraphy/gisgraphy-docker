#!/bin/bash
# this script is use to launch the respawn script

nohup ./respawn.sh ./restart.sh 5 &
